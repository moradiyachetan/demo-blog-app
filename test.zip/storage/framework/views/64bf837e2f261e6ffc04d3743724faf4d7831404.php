<div>
    <?php echo e($slot); ?>

    <?php echo e($title); ?>


    <!-- Well begun is half done. - Aristotle -->
</div>
<?php /**PATH D:\project\blog-app\resources\views/components/header.blade.php ENDPATH**/ ?>