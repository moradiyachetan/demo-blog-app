<h3>Inner Page For Users</h3>
<?php /**PATH D:\project\blog-app\resources\views/inner.blade.php ENDPATH**/ ?>