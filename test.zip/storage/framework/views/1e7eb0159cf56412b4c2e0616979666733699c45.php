<!-- Topbar Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <ul class="list-unstyled topnav-menu float-right mb-0">
            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                    <img src="<?php echo e(asset('assets/images/users/user-1.jpg')); ?>" alt="user-image" class="rounded-circle">
                    <span class="pro-user-name ml-1">
                        <?php echo e(Auth::user()->name); ?> <i class="mdi mdi-chevron-down"></i>
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                    <!-- item-->
                    <div class="dropdown-item noti-title">
                        <h5 class="m-0">
                            Welcome !
                        </h5>
                    </div>

                    <!-- item-->
                
                
                
                

                <!-- item-->
                
                
                
                

                <!-- item-->
                    
                    
                    
                    

                    <div class="dropdown-divider"></div>

                    <!-- item-->
                    
                    
                    
                    

                    <a class="dropdown-item notify-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fe-log-out"></i>
                        <span><?php echo e(__('Logout')); ?></span>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>

                </div>
            </li>

            <li class="dropdown notification-list">
                <a href="javascript:void(0);" class="nav-link right-bar-toggle waves-effect">
                    <i class="fe-settings noti-icon"></i>
                </a>
            </li>

        </ul>

        <!-- LOGO -->
        <div class="logo-box">
            <a href="index.html" class="logo text-center">
                <span class="logo-lg">
                    <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="" height="26">
                    <!-- <span class="logo-lg-text-dark">Upvex</span> -->
                </span>
                <span class="logo-sm">
                    <!-- <span class="logo-sm-text-dark">X</span> -->
                    <img src="<?php echo e(asset('assets/images/logo-sm.png')); ?>" alt="" height="28">
                </span>
            </a>
        </div>


        <div class="clearfix"></div>
    </div>
</div>
<!-- end Topbar -->
<?php /**PATH D:\project\blog-app\resources\views/components/navbar.blade.php ENDPATH**/ ?>