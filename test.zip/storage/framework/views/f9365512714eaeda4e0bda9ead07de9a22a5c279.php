<h2>Welcome To Header Page</h2>
<?php /**PATH D:\project\blog-app\resources\views/partials/header.blade.php ENDPATH**/ ?>