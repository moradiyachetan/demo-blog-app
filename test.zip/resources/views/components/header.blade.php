<header id="topnav">
    <x-menubar/>
    <x-navbar/>
</header>


<div>
{{--    {{$slot}}--}}
{{--    {{$title}}--}}
{{--    <h1>{{$title}} Component</h1>--}}
    <!-- Well begun is half done. - Aristotle -->
</div>
