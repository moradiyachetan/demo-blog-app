<!DOCTYPE html>
<html>
<head>
    <title>@yield('title')</title>

    @stack('style')
</head>
<body>
@yield('content')


</body>
</html>
